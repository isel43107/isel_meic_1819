/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isel.es1819.jp.sgpfdado.dao;

import java.io.Serializable;

/**
 *
 * @author pauloborges
 * @param <T>
 * @param <ID> Identifier
 */
public interface CrudDAO <T, ID extends Serializable>{
    
    ID create(T newInstance);
    
    T read(ID id);
    
    void update(T transientObject);
    
    void delete(T persistentObject);
}
