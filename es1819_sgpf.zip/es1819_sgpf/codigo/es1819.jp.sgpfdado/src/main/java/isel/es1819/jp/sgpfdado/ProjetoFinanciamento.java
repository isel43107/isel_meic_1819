/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isel.es1819.jp.sgpfdado;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author pauloborges
 */
@Entity
@Table(name = "PROJETOFINANCIAMENTO")
@Inheritance(strategy = InheritanceType.JOINED)
public class ProjetoFinanciamento  implements Serializable {
    
    @Id
    @Column(name = "numero_projecto", updatable = false, nullable = false)
    private String numeroProjecto;
    
    //Valor atribuidi
    @Column(name = "custo_elegivel")
    private double custoElegivel;
    
    //Valor Solicitado
    @Column(name = "montante_financiamento")
    private double montanteFinanciamento;
    
    @Column(name = "conta_bancaria")
    private String contaBancaria;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "data_criacao")
    private Date dataCriacao;
    
    
    private Promotor promotor;
    private ResponsavelContato responsavelContato;

    public String getNumeroProjecto() {
        return numeroProjecto;
    }

    public void setNumeroProjecto(String numeroProjecto) {
        this.numeroProjecto = numeroProjecto;
    }

    public double getCustoElegivel() {
        return custoElegivel;
    }

    public void setCustoElegivel(double custoElegivel) {
        this.custoElegivel = custoElegivel;
    }

    public double getMontanteFinanciamento() {
        return montanteFinanciamento;
    }

    public void setMontanteFinanciamento(double montanteFinanciamento) {
        this.montanteFinanciamento = montanteFinanciamento;
    }

    public String getContaBancaria() {
        return contaBancaria;
    }

    public void setContaBancaria(String contaBancaria) {
        this.contaBancaria = contaBancaria;
    }

    public Date getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao;
    }
    
    enum TipoFinanciamento {
        INCENTIVO,
        BONIFICACAO;
    }
    
    
}
