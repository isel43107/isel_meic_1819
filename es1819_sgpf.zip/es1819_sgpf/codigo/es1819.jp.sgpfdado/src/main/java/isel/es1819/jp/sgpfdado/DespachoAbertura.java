/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package isel.es1819.jp.sgpfdado;

import isel.es1819.jp.sgpfdado.utilizador.Utilizador;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author pauloborges
 */
@Entity
@Table(name = "DESPACHO_ABERTURA")
public class DespachoAbertura extends Despacho{
    
    private Utilizador gestorFinanceiro;
}
