/**
 * ISEL - MEIC - Engenharia de Software 2018/2019 
 * Trabalho 02 - SGPF - Consola
 * 
 * 44442 (João Costa)
 * 43107 (Paulo Borges)
 */
package isel.es1819.jp.sgpfconsole;

/**
 *
 * @author jcosta
 */
public class SGPFMainMenuView {

    public void showMenu() {

        System.out.println("\n\r\n\r");
        System.out.println("=============================================");
        System.out.println("a. Aceitação de candidatura;");
        System.out.println("b. Abertura de projecto;");
        System.out.println("c. Parecer técnico;");
        System.out.println("d. Despacho da comissão de financiamento;");
        System.out.println("e. Suspensão de projecto;");
        System.out.println("f. Reactivação de projecto;");
        System.out.println("g. Reforço de projecto;");
        System.out.println("h. Realização de pagamento;");
        System.out.println("i. Alteração de dados de projecto;");
        System.out.println("j. Relatório de informação de projecto;");
        System.out.println("k. Relatório de pagamentos por projecto;");
        System.out.println("sair. Sair aplicação;");
    }
}
