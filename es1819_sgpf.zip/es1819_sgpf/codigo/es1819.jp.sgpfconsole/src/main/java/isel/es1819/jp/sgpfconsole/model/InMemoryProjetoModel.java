/**
 * ISEL - MEIC - Engenharia de Software 2018/2019 
 * Trabalho 02 - SGPF - Consola
 * 
 * 44442 (João Costa)
 * 43107 (Paulo Borges)
 */
package isel.es1819.jp.sgpfconsole.model;

/**
 *
 * @author pauloborges
 */
public class InMemoryProjetoModel implements ProjetoModel{
    
}
